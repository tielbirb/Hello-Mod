package com.tielcraft.dumbhello;

import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.FOVUpdateEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.util.ArrayList;
import java.util.List;

public class HelloHandler {

    // Distances in blocks
    private static final double VERY_CLOSE = 6.0;
    private static final double NEAR = 18.0;

    // Zoom multipliers applied to FOV (smaller = more zoom)
    private static final float ZOOM_MAX = 0.18f;   // ALOT
    private static final float ZOOM_ONCE = 0.65f;  // single moderate zoom
    private static final float ZOOM_NONE = 1.0f;

    private static final int SPAM_DELAY_TICKS = 6;

    private float currentZoom = 1.0f;
    private float targetZoom = 1.0f;
    private boolean playedForThisApproach = false;
    private int spamCooldown = 0;

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        Minecraft mc = Minecraft.getMinecraft();
        EntityPlayer player = mc.player;
        if (mc.world == null || player == null || mc.isGamePaused()) {
            targetZoom = ZOOM_NONE;
            currentZoom = ZOOM_NONE;
            playedForThisApproach = false;
            return;
        }

        double nearest = nearestHostileDistance(mc, player);

        if (nearest <= VERY_CLOSE) {
            // Super near: huge zoom + sound spam
            targetZoom = ZOOM_MAX;
            playedForThisApproach = true;
            if (spamCooldown-- <= 0) {
                playHello(mc);
                spamCooldown = SPAM_DELAY_TICKS;
            }
        } else if (nearest <= NEAR) {
            // Near but not super near: sound + zoom exactly once per approach
            if (!playedForThisApproach) {
                playedForThisApproach = true;
                playHello(mc);
                targetZoom = ZOOM_ONCE;
            } else if (targetZoom < ZOOM_ONCE) {
                // came back from "very close" -> settle at the single zoom level
                targetZoom = ZOOM_ONCE;
            }
            spamCooldown = 0;
        } else {
            // Far away from every enemy: camera reverts, ready to trigger again
            targetZoom = ZOOM_NONE;
            playedForThisApproach = false;
            spamCooldown = 0;
        }

        // Smooth easing (snappy zoom-in, slower revert)
        float speed = targetZoom < currentZoom ? 0.35f : 0.12f;
        currentZoom += (targetZoom - currentZoom) * speed;
        if (Math.abs(currentZoom - targetZoom) < 0.002f) currentZoom = targetZoom;
    }

    @SubscribeEvent
    public void onFov(FOVUpdateEvent event) {
        if (currentZoom != ZOOM_NONE) {
            event.setNewfov(event.getNewfov() * currentZoom);
        }
    }

    private double nearestHostileDistance(Minecraft mc, EntityPlayer player) {
        double best = Double.MAX_VALUE;
        List<Entity> entities = new ArrayList<>(mc.world.loadedEntityList);
        for (Entity e : entities) {
            if (e == player || e.isDead || !(e instanceof IMob)) continue;
            double d = e.getDistance(player);
            if (d < best) best = d;
        }
        return best;
    }

    private void playHello(Minecraft mc) {
        if (DumbHelloMod.HELLO == null) return;
        mc.getSoundHandler().playSound(PositionedSoundRecord.getMasterRecord(DumbHelloMod.HELLO, 1.0F));
    }
}
