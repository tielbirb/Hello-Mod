package com.tielcraft.dumbhello;

import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/**
 * TielCraft's Dumb Hello mod.
 * Client-side only effects: sound + camera zoom when hostile mobs are near.
 * GeckoLib is declared as a required dependency (modid "geckolib3").
 */
@Mod(modid = DumbHelloMod.MODID,
     name = DumbHelloMod.NAME,
     version = "1.0.0",
     acceptedMinecraftVersions = "[1.12.2]",
     dependencies = "required-after:geckolib3",
     clientSideOnly = true)
@Mod.EventBusSubscriber
public class DumbHelloMod {
    public static final String MODID = "tielcraft_dumb_hello";
    public static final String NAME = "TielCraft's Dumb Hello mod";

    public static SoundEvent HELLO;

    @SubscribeEvent
    public static void registerSounds(RegistryEvent.Register<SoundEvent> event) {
        ResourceLocation id = new ResourceLocation(MODID, "hello");
        HELLO = new SoundEvent(id).setRegistryName(id);
        event.getRegistry().register(HELLO);
    }

    @Mod.EventHandler
    public void init(net.minecraftforge.fml.common.event.FMLInitializationEvent e) {
        net.minecraftforge.common.MinecraftForge.EVENT_BUS.register(new HelloHandler());
    }
}
