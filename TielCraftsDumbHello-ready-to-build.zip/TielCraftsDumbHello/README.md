# TielCraft's Dumb Hello mod (Forge 1.12.2)

Adds the Hello sound effect from Raldi's Crackhouse to Minecraft 1.12.2.
**You need GeckoLib (geckolib3) for the zoom thingy.**

## Behavior
- Hostile mob within ~18 blocks: plays Hello once and zooms in once.
- Hostile mob within ~6 blocks: camera zooms in A LOT and Hello gets spammed.
- Away from all enemies: camera eases back to normal.

## Build
1. Install JDK 8, then in this folder run `gradlew build` (add the Forge 1.12.2 MDK gradle wrapper if missing).
2. Jar appears in `build/libs/`.
3. Drop it in `mods/` together with GeckoLib for 1.12.2.

Tweak distances/zoom in `HelloHandler.java` (VERY_CLOSE, NEAR, ZOOM_MAX, ZOOM_ONCE).

## Linux build (wrapper already included)
```
sudo apt install openjdk-8-jdk    # or use sdkman: sdk install java 8.0.402-tem
export JAVA_HOME=/path/to/jdk8
./gradlew setupDecompWorkspace
./gradlew build
```
Jar: build/libs/TielCraftsDumbHello-1.12.2-1.0.0.jar
